var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => VaultSyncPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/security.ts
var import_crypto = require("crypto");
var import_promises = require("fs/promises");
var import_path = require("path");
var import_child_process = require("child_process");
var import_util = require("util");
var execFileAsync = (0, import_util.promisify)(import_child_process.execFile);
var SecurityUtils = class {
  /**
   * Sanitize commit message to prevent command injection
   */
  static sanitizeCommitMessage(message) {
    if (!message || typeof message !== "string") {
      return "Vault sync - automated";
    }
    let sanitized = message;
    this.DANGEROUS_PATTERNS.forEach((pattern) => {
      sanitized = sanitized.replace(pattern, "");
    });
    sanitized = sanitized.replace(/'/g, "''").replace(/"/g, '\\"').replace(/\\/g, "\\\\").trim().slice(0, 200);
    if (!sanitized) {
      return "Vault sync - automated";
    }
    return sanitized;
  }
  /**
   * Validate and normalize vault path
   */
  static async validateVaultPath(vaultPath) {
    if (!vaultPath || typeof vaultPath !== "string") {
      throw new Error("Invalid vault path: path must be a non-empty string");
    }
    const normalizedPath = (0, import_path.normalize)((0, import_path.resolve)(vaultPath));
    if (normalizedPath.includes("..")) {
      throw new Error("Invalid vault path: path traversal detected");
    }
    try {
      await (0, import_promises.access)(normalizedPath, import_promises.constants.R_OK | import_promises.constants.W_OK);
      const stats = await (0, import_promises.stat)(normalizedPath);
      if (!stats.isDirectory()) {
        throw new Error("Invalid vault path: path is not a directory");
      }
    } catch (error) {
      throw new Error(`Invalid vault path: ${error.message}`);
    }
    return normalizedPath;
  }
  /**
   * Validate script name against allowed list
   */
  static validateScriptName(scriptName) {
    if (!scriptName || typeof scriptName !== "string") {
      return false;
    }
    return this.ALLOWED_SCRIPT_NAMES.includes(scriptName);
  }
  /**
   * Validate script file exists and has proper permissions
   */
  static async validateScriptFile(scriptPath) {
    try {
      await (0, import_promises.access)(scriptPath, import_promises.constants.R_OK | import_promises.constants.X_OK);
      const stats = await (0, import_promises.stat)(scriptPath);
      if (!stats.isFile()) {
        throw new Error("Script path is not a file");
      }
      const mode = stats.mode;
      if (!(mode & import_promises.constants.S_IRUSR) || !(mode & import_promises.constants.S_IXUSR)) {
        throw new Error("Script file lacks proper permissions");
      }
    } catch (error) {
      throw new Error(`Script validation failed: ${error.message}`);
    }
  }
  /**
   * Calculate script checksum for integrity verification
   */
  static async calculateScriptChecksum(scriptPath) {
    try {
      const content = await (0, import_promises.readFile)(scriptPath, "utf8");
      return (0, import_crypto.createHash)("sha256").update(content).digest("hex");
    } catch (error) {
      throw new Error(`Failed to calculate script checksum: ${error.message}`);
    }
  }
  /**
   * Verify script content doesn't contain malicious patterns
   */
  static async verifyScriptContent(scriptPath) {
    try {
      const content = await (0, import_promises.readFile)(scriptPath, "utf8");
      const suspiciousPatterns = [
        /rm\s+-rf\s+\/(?!tmp|var\/tmp)/g,
        // Dangerous rm commands (except tmp)
        /sudo\s+(?!git|bash)/g,
        // Sudo with non-git commands
        /curl\s+.*\|\s*sh/g,
        // Pipe to shell
        /wget\s+.*\|\s*sh/g,
        // Pipe to shell
        /eval\s+/g,
        // Eval commands
        /exec\s+/g,
        // Exec commands
        /\$\(\s*cat\s+.*\s*\)/g,
        // Command substitution with cat
        />\s*\/dev\/null\s*2>&1\s*&/g,
        // Background processes
        /nohup\s+/g,
        // Background processes
        /\$\(.*\$\(.*\)\)/g,
        // Nested command substitution
        /\${.*}/g,
        // Parameter expansion
        /\n\s*\n.*rm\s+/g,
        // Hidden rm commands
        /;.*rm\s+/g,
        // Chained rm commands
        /&{1,2}.*rm\s+/g,
        // Conditional rm commands
        /\|\s*rm\s+/g,
        // Piped rm commands
        />\s*\/(?!tmp|var\/tmp)/g,
        // Redirect to system paths
        />\s*\/etc\//g,
        // Redirect to /etc
        />\s*\/usr\//g,
        // Redirect to /usr
        />\s*\/var\/(?!tmp)/g,
        // Redirect to /var (except tmp)
        />\s*\/root\//g,
        // Redirect to /root
        />\s*\/home\/.*\/\.ssh\//g,
        // Redirect to SSH directories
        />\s*\/home\/.*\/\.bash/g,
        // Redirect to bash config
        />\s*\/home\/.*\/\.profile/g,
        // Redirect to profile
        />\s*\/home\/.*\/\.zsh/g,
        // Redirect to zsh config
        /chmod\s+777/g,
        // World writable permissions
        /chown\s+root/g,
        // Root ownership
        /su\s+-/g,
        // Switch user
        /passwd\s+/g,
        // Password changes
        /useradd\s+/g,
        // User creation
        /userdel\s+/g,
        // User deletion
        /usermod\s+/g,
        // User modification
        /crontab\s+/g,
        // Cron job modification
        /systemctl\s+/g,
        // System service control
        /service\s+/g,
        // Service control
        /mount\s+/g,
        // Mount operations
        /umount\s+/g,
        // Unmount operations
        /dd\s+if=/g,
        // Disk operations
        /mkfs\s+/g,
        // Filesystem creation
        /fdisk\s+/g,
        // Disk partitioning
        /iptables\s+/g,
        // Firewall rules
        /netstat\s+/g,
        // Network monitoring
        /nc\s+/g,
        // Netcat
        /nmap\s+/g,
        // Network scanning
        /ssh\s+.*@/g,
        // SSH connections
        /scp\s+/g,
        // SCP transfers
        /rsync\s+/g,
        // Rsync (allow only local)
        /ftp\s+/g,
        // FTP connections
        /telnet\s+/g,
        // Telnet connections
        /python\s+.*-c/g,
        // Python one-liners
        /perl\s+.*-e/g,
        // Perl one-liners
        /ruby\s+.*-e/g,
        // Ruby one-liners
        /node\s+.*-e/g,
        // Node one-liners
        /php\s+.*-r/g,
        // PHP one-liners
        /base64\s+.*-d/g,
        // Base64 decode
        /echo\s+.*\|\s*base64/g,
        // Base64 encode
        /openssl\s+.*-d/g,
        // OpenSSL decrypt
        /gpg\s+.*--decrypt/g,
        // GPG decrypt
        /tar\s+.*-x.*-f/g,
        // Archive extraction
        /unzip\s+/g,
        // Unzip operations
        /7z\s+x/g,
        // 7zip extraction
        /\.\.\/\.\.\//g,
        // Path traversal
        /\/proc\/self\/environ/g,
        // Environment access
        /\/proc\/self\/cmdline/g,
        // Command line access
        /\/proc\/version/g,
        // Version info access
        /\/proc\/meminfo/g,
        // Memory info access
        /\/proc\/cpuinfo/g,
        // CPU info access
        /\/etc\/passwd/g,
        // Password file access
        /\/etc\/shadow/g,
        // Shadow file access
        /\/etc\/hosts/g,
        // Hosts file access
        /\/etc\/resolv\.conf/g,
        // DNS config access
        /\/etc\/fstab/g,
        // Filesystem table access
        /\/etc\/crontab/g,
        // Cron config access
        /\/etc\/sudoers/g,
        // Sudo config access
        /\/root\/\./g,
        // Root directory access
        /\/home\/[^\/]+\/\./g,
        // Home directory access
        /~\/\./g,
        // Home directory access
        /\$HOME\/\./g,
        // Home directory access
        /\$USER/g,
        // User variable access
        /\$SHELL/g,
        // Shell variable access
        /\$PATH/g,
        // PATH variable access
        /\$PWD/g,
        // PWD variable access
        /\$OLDPWD/g,
        // OLDPWD variable access
        /\$TMPDIR/g,
        // TMPDIR variable access
        /\$TEMP/g,
        // TEMP variable access
        /\$TMP/g
        // TMP variable access
      ];
      for (const pattern of suspiciousPatterns) {
        if (pattern.test(content)) {
          throw new Error(`Script contains suspicious pattern: ${pattern.source}`);
        }
      }
      if (!content.includes("git add") || !content.includes("git commit")) {
        throw new Error("Script must contain basic git operations");
      }
      if (!content.startsWith("#!/bin/bash") && !content.startsWith("#!/bin/sh")) {
        throw new Error("Script must start with proper shebang");
      }
    } catch (error) {
      throw new Error(`Script content verification failed: ${error.message}`);
    }
  }
  /**
   * Secure command execution with timeout and resource limits
   */
  static async executeSecureCommand(command, args, options) {
    const { cwd, timeout = 3e4, maxBuffer = 1024 * 1024, env = {} } = options;
    if (!command || typeof command !== "string") {
      throw new Error("Invalid command");
    }
    if (command !== "bash" && command !== "sh") {
      throw new Error("Only bash and sh commands are allowed");
    }
    if (!Array.isArray(args)) {
      throw new Error("Arguments must be an array");
    }
    const validatedCwd = await this.validateVaultPath(cwd);
    const secureEnv = {
      ...process.env,
      ...env,
      PATH: process.env.PATH || "",
      HOME: process.env.HOME || "",
      USER: process.env.USER || "",
      SHELL: "/bin/bash",
      TERM: "xterm",
      LANG: "en_US.UTF-8",
      LC_ALL: "en_US.UTF-8"
    };
    delete secureEnv.LD_PRELOAD;
    delete secureEnv.LD_LIBRARY_PATH;
    delete secureEnv.DYLD_INSERT_LIBRARIES;
    delete secureEnv.DYLD_LIBRARY_PATH;
    try {
      const result = await execFileAsync(command, args, {
        cwd: validatedCwd,
        timeout,
        maxBuffer,
        env: secureEnv,
        uid: process.getuid?.(),
        gid: process.getgid?.()
      });
      return {
        stdout: result.stdout || "",
        stderr: result.stderr || ""
      };
    } catch (error) {
      throw new Error(`Command execution failed: ${error.message}`);
    }
  }
  /**
   * Validate Git repository
   */
  static async validateGitRepository(vaultPath) {
    const validatedPath = await this.validateVaultPath(vaultPath);
    try {
      const gitPath = (0, import_path.join)(validatedPath, ".git");
      await (0, import_promises.access)(gitPath, import_promises.constants.R_OK);
      const result = await this.executeSecureCommand("git", ["rev-parse", "--git-dir"], {
        cwd: validatedPath,
        timeout: 5e3
      });
      if (!result.stdout.trim()) {
        throw new Error("Not a valid git repository");
      }
    } catch (error) {
      throw new Error(`Git repository validation failed: ${error.message}`);
    }
  }
  /**
   * Validate Git remote
   */
  static async validateGitRemote(vaultPath) {
    const validatedPath = await this.validateVaultPath(vaultPath);
    try {
      const result = await this.executeSecureCommand("git", ["remote", "get-url", "origin"], {
        cwd: validatedPath,
        timeout: 5e3
      });
      if (!result.stdout.trim()) {
        throw new Error("No remote origin configured");
      }
    } catch (error) {
      throw new Error(`Git remote validation failed: ${error.message}`);
    }
  }
};
SecurityUtils.ALLOWED_SCRIPT_NAMES = [
  "sync-vault.sh",
  "sync-vault-advanced.sh",
  "sync-vault-optimized.sh",
  "sync-vault-coordinated.sh"
];
SecurityUtils.DANGEROUS_PATTERNS = [
  /[`$\\]/g,
  // Command substitution and escaping
  /[;&|]/g,
  // Command chaining
  /\$\(/g,
  // Command substitution
  /\$\{/g,
  // Parameter expansion
  /\n|\r/g,
  // Line breaks
  /\x00/g,
  // Null bytes
  /\.\./g,
  // Path traversal
  /\/proc\//g,
  // Process filesystem
  /\/sys\//g,
  // System filesystem
  /\/dev\//g,
  // Device filesystem
  /rm\s+-rf/g,
  // Dangerous rm commands
  /sudo/g,
  // Privilege escalation
  /su\s/g,
  // User switching
  /chmod\s+\d{3,4}/g,
  // Permission changes
  /chown/g,
  // Ownership changes
  /curl\s+.*\|\s*sh/g,
  // Pipe to shell
  /wget\s+.*\|\s*sh/g
  // Pipe to shell
];

// src/main.ts
var import_path2 = require("path");
var DEFAULT_SETTINGS = {
  syncScript: "sync-vault-coordinated.sh",
  autoSyncInterval: 5,
  autoSyncEnabled: false,
  showNotifications: true,
  syncOnStartup: false,
  lastSyncTime: null,
  syncCount: 0,
  securityMode: "strict",
  scriptChecksums: {}
};
var VaultSyncPlugin = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    this.autoSyncInterval = null;
    this.lastSyncTime = null;
    this.syncCount = 0;
  }
  async onload() {
    console.log("Loading Vault Sync Plugin...");
    try {
      await this.loadSettings();
      this.addRibbonIcon("sync", "Vault Sync", () => this.syncVault());
      this.addCommand({
        id: "sync-vault-manual",
        name: "Sync Vault (Manual)",
        callback: () => this.syncVault()
      });
      this.addCommand({
        id: "toggle-auto-sync",
        name: "Toggle Auto-Sync",
        callback: () => this.toggleAutoSync()
      });
      this.addCommand({
        id: "view-sync-status",
        name: "View Sync Status",
        callback: () => this.showSyncStatus()
      });
      this.addCommand({
        id: "verify-script-integrity",
        name: "Verify Script Integrity",
        callback: () => this.verifyScriptIntegrity()
      });
      this.addSettingTab(new VaultSyncSettingTab(this.app, this));
      this.statusBarItemEl = this.addStatusBarItem();
      this.updateStatusBar();
      this.setupAutoSync();
      await this.initializeSecurityChecksums();
      console.log("Vault Sync Plugin loaded successfully");
    } catch (error) {
      console.error("Error loading Vault Sync Plugin:", error);
      new import_obsidian.Notice(`\u274C Plugin load failed: ${error.message}`, 5e3);
    }
  }
  onunload() {
    console.log("Unloading Vault Sync Plugin...");
    try {
      this.clearAutoSync();
      console.log("Vault Sync Plugin unloaded successfully");
    } catch (error) {
      console.error("Error unloading Vault Sync Plugin:", error);
    }
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.lastSyncTime = this.settings.lastSyncTime;
    this.syncCount = this.settings.syncCount || 0;
  }
  async saveSettings() {
    this.settings.lastSyncTime = this.lastSyncTime;
    this.settings.syncCount = this.syncCount;
    await this.saveData(this.settings);
  }
  /**
   * Initialize security checksums for sync scripts
   */
  async initializeSecurityChecksums() {
    try {
      const vaultPath = this.app.vault.adapter.basePath;
      const validatedPath = await SecurityUtils.validateVaultPath(vaultPath);
      const scripts = [
        "sync-vault.sh",
        "sync-vault-advanced.sh",
        "sync-vault-optimized.sh",
        "sync-vault-coordinated.sh"
      ];
      for (const script of scripts) {
        const scriptPath = (0, import_path2.join)(validatedPath, script);
        try {
          await SecurityUtils.validateScriptFile(scriptPath);
          const checksum = await SecurityUtils.calculateScriptChecksum(scriptPath);
          if (!this.settings.scriptChecksums[script] || this.settings.scriptChecksums[script] !== checksum) {
            this.settings.scriptChecksums[script] = checksum;
            console.log(`Updated checksum for ${script}`);
          }
        } catch (error) {
          console.warn(`Script ${script} not found or invalid:`, error.message);
        }
      }
      await this.saveSettings();
    } catch (error) {
      console.error("Failed to initialize security checksums:", error);
    }
  }
  /**
   * Verify script integrity before sync
   */
  async verifyScriptIntegrity() {
    if (this.settings.securityMode === "permissive") {
      return true;
    }
    try {
      const vaultPath = this.app.vault.adapter.basePath;
      const validatedPath = await SecurityUtils.validateVaultPath(vaultPath);
      const scriptPath = (0, import_path2.join)(validatedPath, this.settings.syncScript);
      if (!SecurityUtils.validateScriptName(this.settings.syncScript)) {
        throw new Error(`Invalid script name: ${this.settings.syncScript}`);
      }
      await SecurityUtils.validateScriptFile(scriptPath);
      await SecurityUtils.verifyScriptContent(scriptPath);
      if (this.settings.securityMode === "strict") {
        const currentChecksum = await SecurityUtils.calculateScriptChecksum(scriptPath);
        const storedChecksum = this.settings.scriptChecksums[this.settings.syncScript];
        if (storedChecksum && currentChecksum !== storedChecksum) {
          throw new Error("Script integrity check failed - checksum mismatch");
        }
      }
      return true;
    } catch (error) {
      console.error("Script integrity verification failed:", error);
      new import_obsidian.Notice(`\u274C Script integrity check failed: ${error.message}`, 5e3);
      return false;
    }
  }
  /**
   * Validate vault environment before sync
   */
  async validateVaultEnvironment() {
    try {
      const vaultPath = this.app.vault.adapter.basePath;
      await SecurityUtils.validateVaultPath(vaultPath);
      await SecurityUtils.validateGitRepository(vaultPath);
      await SecurityUtils.validateGitRemote(vaultPath);
      return true;
    } catch (error) {
      console.error("Vault environment validation failed:", error);
      new import_obsidian.Notice(`\u274C Vault validation failed: ${error.message}`, 5e3);
      return false;
    }
  }
  setupAutoSync() {
    this.clearAutoSync();
    if (this.settings.autoSyncEnabled) {
      const intervalMs = this.settings.autoSyncInterval * 60 * 1e3;
      this.autoSyncInterval = setInterval(() => {
        this.syncVault();
      }, intervalMs);
    }
  }
  clearAutoSync() {
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
      this.autoSyncInterval = null;
    }
  }
  /**
   * Force script integrity verification (manual command)
   */
  async verifyScriptIntegrity() {
    const result = await this.verifyScriptIntegrity();
    if (result) {
      new import_obsidian.Notice("\u2705 Script integrity verified", 2e3);
    }
  }
  /**
   * Update script checksum (for when scripts are legitimately updated)
   */
  async updateScriptChecksum() {
    try {
      const vaultPath = this.app.vault.adapter.basePath;
      const validatedPath = await SecurityUtils.validateVaultPath(vaultPath);
      const scriptPath = (0, import_path2.join)(validatedPath, this.settings.syncScript);
      await SecurityUtils.validateScriptFile(scriptPath);
      await SecurityUtils.verifyScriptContent(scriptPath);
      const checksum = await SecurityUtils.calculateScriptChecksum(scriptPath);
      this.settings.scriptChecksums[this.settings.syncScript] = checksum;
      await this.saveSettings();
      new import_obsidian.Notice("\u2705 Script checksum updated", 2e3);
    } catch (error) {
      new import_obsidian.Notice(`\u274C Failed to update checksum: ${error.message}`, 3e3);
    }
  }
};
var VaultSyncSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Vault Sync Settings" });
    const securityDiv = containerEl.createDiv();
    securityDiv.style.background = this.plugin.settings.securityMode === "strict" ? "#e8f5e8" : this.plugin.settings.securityMode === "normal" ? "#fff3cd" : "#f8d7da";
    securityDiv.style.padding = "15px";
    securityDiv.style.borderRadius = "5px";
    securityDiv.style.marginBottom = "20px";
    securityDiv.style.border = "1px solid " + (this.plugin.settings.securityMode === "strict" ? "#d4edda" : this.plugin.settings.securityMode === "normal" ? "#ffeaa7" : "#f5c6cb");
    const securityIcon = this.plugin.settings.securityMode === "strict" ? "\u{1F512}" : this.plugin.settings.securityMode === "normal" ? "\u{1F513}" : "\u26A0\uFE0F";
    securityDiv.innerHTML = `
            <h3>${securityIcon} Security Status</h3>
            <p><strong>Mode:</strong> ${this.plugin.settings.securityMode.charAt(0).toUpperCase() + this.plugin.settings.securityMode.slice(1)}</p>
            <p><strong>Script Integrity:</strong> ${Object.keys(this.plugin.settings.scriptChecksums).length} scripts verified</p>
            <p><strong>Current Script:</strong> ${this.plugin.settings.syncScript}</p>
            <p><strong>Checksum:</strong> ${this.plugin.settings.scriptChecksums[this.plugin.settings.syncScript]?.slice(0, 16) || "Not verified"}...</p>
        `;
    const statusDiv = containerEl.createDiv();
    statusDiv.style.background = "#f5f5f5";
    statusDiv.style.padding = "15px";
    statusDiv.style.borderRadius = "5px";
    statusDiv.style.marginBottom = "20px";
    statusDiv.innerHTML = `
            <h3>\u{1F504} Sync Status</h3>
            <p><strong>Auto-sync:</strong> ${this.plugin.settings.autoSyncEnabled ? `\u2705 Enabled (${this.plugin.settings.autoSyncInterval}m)` : "\u274C Disabled"}</p>
            <p><strong>Last sync:</strong> ${this.plugin.getTimeSinceLastSync()}</p>
            <p><strong>Total syncs:</strong> ${this.plugin.syncCount}</p>
            <p><strong>Script:</strong> ${this.plugin.settings.syncScript}</p>
        `;
    new import_obsidian.Setting(containerEl).setName("Security Mode").setDesc("Choose security level for sync operations").addDropdown((dropdown) => dropdown.addOption("strict", "\u{1F512} Strict - Full validation + integrity checks").addOption("normal", "\u{1F513} Normal - Basic validation only").addOption("permissive", "\u26A0\uFE0F Permissive - Minimal validation (not recommended)").setValue(this.plugin.settings.securityMode).onChange(async (value) => {
      this.plugin.settings.securityMode = value;
      await this.plugin.saveSettings();
      this.plugin.updateStatusBar();
      this.display();
    }));
    new import_obsidian.Setting(containerEl).setName("Sync Script").setDesc("Which sync script to use (automatically validated)").addDropdown((dropdown) => dropdown.addOption("sync-vault.sh", "Basic").addOption("sync-vault-advanced.sh", "Advanced").addOption("sync-vault-optimized.sh", "Optimized").addOption("sync-vault-coordinated.sh", "With iCloud").setValue(this.plugin.settings.syncScript).onChange(async (value) => {
      this.plugin.settings.syncScript = value;
      await this.plugin.saveSettings();
      this.display();
    }));
    new import_obsidian.Setting(containerEl).setName("Enable Auto-sync").setDesc("Automatically sync at regular intervals with security checks").addToggle((toggle) => toggle.setValue(this.plugin.settings.autoSyncEnabled).onChange(async (value) => {
      this.plugin.settings.autoSyncEnabled = value;
      await this.plugin.saveSettings();
      if (value) {
        this.plugin.setupAutoSync();
      } else {
        this.plugin.clearAutoSync();
      }
      this.plugin.updateStatusBar();
      this.display();
    }));
    new import_obsidian.Setting(containerEl).setName("Auto-sync Interval").setDesc("Minutes between automatic syncs").addSlider((slider) => slider.setLimits(1, 60, 1).setValue(this.plugin.settings.autoSyncInterval).setDynamicTooltip().onChange(async (value) => {
      this.plugin.settings.autoSyncInterval = value;
      await this.plugin.saveSettings();
      if (this.plugin.settings.autoSyncEnabled) {
        this.plugin.setupAutoSync();
      }
      this.plugin.updateStatusBar();
      this.display();
    }));
    new import_obsidian.Setting(containerEl).setName("Show Notifications").setDesc("Display sync status messages").addToggle((toggle) => toggle.setValue(this.plugin.settings.showNotifications).onChange(async (value) => {
      this.plugin.settings.showNotifications = value;
      await this.plugin.saveSettings();
    }));
    containerEl.createEl("h3", { text: "\u26A1 Actions" });
    new import_obsidian.Setting(containerEl).setName("Sync Now").setDesc("Manually trigger a secure sync").addButton((button) => button.setButtonText("\u{1F504} Sync").onClick(() => this.plugin.syncVault()));
    new import_obsidian.Setting(containerEl).setName("View Status").setDesc("Show detailed sync status").addButton((button) => button.setButtonText("\u{1F4CA} Status").onClick(() => this.plugin.showSyncStatus()));
    new import_obsidian.Setting(containerEl).setName("Verify Script").setDesc("Manually verify script integrity").addButton((button) => button.setButtonText("\u{1F50D} Verify").onClick(() => this.plugin.verifyScriptIntegrity()));
    new import_obsidian.Setting(containerEl).setName("Update Checksum").setDesc("Update script checksum after legitimate changes").addButton((button) => button.setButtonText("\u{1F504} Update").onClick(() => this.plugin.updateScriptChecksum()));
    new import_obsidian.Setting(containerEl).setName("Reset Counter").setDesc("Reset sync counter to zero").addButton((button) => button.setButtonText("\u{1F504} Reset").onClick(async () => {
      this.plugin.syncCount = 0;
      await this.plugin.saveSettings();
      this.plugin.updateStatusBar();
      this.display();
      new import_obsidian.Notice("Counter reset");
    }));
    containerEl.createEl("h3", { text: "\u{1F6E1}\uFE0F Security Information" });
    const securityInfo = containerEl.createDiv();
    securityInfo.style.background = "#f8f9fa";
    securityInfo.style.padding = "10px";
    securityInfo.style.borderRadius = "5px";
    securityInfo.style.fontSize = "0.9em";
    securityInfo.style.marginTop = "10px";
    securityInfo.innerHTML = `
            <p><strong>\u{1F512} Strict Mode:</strong> Full input sanitization, path validation, script integrity checking, and secure command execution.</p>
            <p><strong>\u{1F513} Normal Mode:</strong> Basic input sanitization and path validation without integrity checks.</p>
            <p><strong>\u26A0\uFE0F Permissive Mode:</strong> Minimal validation - only use if you understand the security implications.</p>
            <br>
            <p><strong>Security Features:</strong></p>
            <ul>
                <li>Command injection prevention</li>
                <li>Path traversal protection</li>
                <li>Script integrity verification</li>
                <li>Secure environment execution</li>
                <li>Input sanitization</li>
                <li>Resource limits</li>
            </ul>
        `;
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
